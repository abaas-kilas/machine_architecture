#include <stdio.h>
char greeting[64] = "Hello fine folks!";
int ngreet = 5;

void print_greeting(){
  printf("%s\n", greeting);
}
